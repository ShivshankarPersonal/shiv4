(function () {
    angular.module("dashboard")
        .controller("videoDashboard", function ($scope,$location) {
            $scope.greeting = "Video Dashboard";
            $scope.pageName = "Video Dashboard Page";
            if (!sessionStorage.getItem('loginId')) {
                $location.path("/login");
            }
            $scope.logoutBtn = true;
            $scope.onLogout = function(){
                $location.path("/login");
                sessionStorage.removeItem('loginId');
            };
            $scope.onGraphBtnClick = function () {
                if (sessionStorage.getItem('loginId')) {
                    $location.path("/graphs_dashboard");
                }
            };
        });
})();
