(function () {
    angular.module("dashboard")
        .controller("graphsDashboard", function ($scope, $location) {
            $scope.greeting = "Graphs Dashboard";
            $scope.pageName = "Graph Dashboard Page";
            if (!sessionStorage.getItem('loginId')) {
                $location.path("/login");
            }
            $scope.logoutBtn = true;
            $scope.onLogout = function () {
                $location.path("/login");
                sessionStorage.removeItem('loginId');
            };
        });
})();